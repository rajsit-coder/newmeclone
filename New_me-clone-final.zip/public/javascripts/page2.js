function goBack() {
    window.history.back();
}

window.addEventListener('popstate', function(event) {});